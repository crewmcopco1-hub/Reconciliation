﻿using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace VDSReconciliation.Services
{

    public class ServiceBusPublisher : IServiceBusPublisher
    {
        private readonly ServiceBusClient _client;
        private readonly ILogger<ServiceBusPublisher> _logger;

        public ServiceBusPublisher(
            ServiceBusClient client,
            ILogger<ServiceBusPublisher> logger)
        {
            _client = client;
            _logger = logger;
        }

        public async Task PublishAuthorityMessageAsync(
            AuthorityMessage msg,
            string? topicName = null)
        {
            topicName = string.IsNullOrWhiteSpace(topicName)
                ? "ApplicationAccessRaw"
                : topicName;

            try
            {
                var sender = _client.CreateSender(topicName);

                var json = JsonSerializer.Serialize(msg);

                var sbMessage = new ServiceBusMessage(json)
                {
                    MessageId = msg.MessageId,
                    CorrelationId = msg.CorrelationId
                };

                sbMessage.ApplicationProperties["Source"] = msg.Source;

                await sender.SendMessageAsync(sbMessage);

                _logger.LogInformation(
                    "{Component} - {Source} - {UserId} - {LocationId} - {ApplicationId}: Message published successfully. {@Info}",
                    "VDSReconciliation",
                    "PublishAuthorityMessage",
                    msg.Object.Attributes.user_id,
                    msg.Object.Attributes.location_id,
                    msg.Object.Attributes.application_id,
                    new
                    {
                        Status = "Success",
                        msg.MessageId,
                        msg.CorrelationId,
                        TimeStampUTC = DateTime.UtcNow
                    });
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "{Component} - {Source} - {UserId} - {LocationId} - {ApplicationId}: Failed to publish message. {@Info}",
                    "VDSReconciliation",
                    "PublishAuthorityMessage",
                    msg.Object.Attributes.user_id,
                    msg.Object.Attributes.location_id,
                    msg.Object.Attributes.application_id,
                    new
                    {
                        Status = "Failed",
                        msg.CorrelationId,
                        TimeStampUTC = DateTime.UtcNow
                    });

                throw;
            }
        }
    }

}
